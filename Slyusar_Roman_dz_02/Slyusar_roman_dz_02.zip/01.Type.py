"""
1. Выяснить тип результата выражений:
15 * 3
15 / 3
15 // 2
15 ** 2
"""

expression_1 = 15 * 3
expression_2 = 15 / 3
expression_3 = 15 // 2
expression_4 = 15 ** 2

print(expression_1, type(expression_1))
print(expression_2, type(expression_2))
print(expression_3, type(expression_3))
print(expression_4, type(expression_4))
